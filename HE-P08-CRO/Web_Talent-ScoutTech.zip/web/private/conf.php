<?php

$db = new SQLite3(dirname(__FILE__) . "/database.db") or die ("Unable to open database");

?>